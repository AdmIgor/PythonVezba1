broj = int(input('Unesite ceo broj: '))
if broj>100:
    print("Broj ",broj," je veci od 100")
elif broj==100:
    print("Broj ",broj," je veci od 100")
else:
    print("Broj ", broj," je manji od 100")
    if broj%2==0:
        print("Broj ",broj," je paran")
    else:
        print("Broj ",broj," je neparan")
