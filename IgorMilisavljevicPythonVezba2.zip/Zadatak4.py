for broj in range(2,51):
    provera = 1    
    for n in range(2,broj):
        if(broj%n==0):
            provera=0
            break
    if provera==1:
        print(broj)
