broj = int(input('Unesite broj: '))
fakt = 1
for b in range(1,broj+1):
    fakt = fakt *b
print('Faktorijel broja ',broj,' je : ',fakt)
