a=int(input('Unesite broj od 1 do 12: '))
meseci=["","Januar","Februar","Mart","April","Maj","Jun","Jul","Avgust","Septembar","Oktobar","Novembar","Decembar"]
if(a>=1 and a<=12):
   print(meseci[a])
else:
   print("Broj nije u dozvoljenom opsegu")
