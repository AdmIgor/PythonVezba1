print('Dobrodosli u kviz "C Programski jezik" ')
ime = str(input('Unesite Vase ime: '))
nova = 1
while nova==1:
    tacni = 0
    print('Pitanje 1.Koja se komanda koristi za kreiranje direktorijuma?')
    print('1. rm')
    print('2. mkdir')
    print('3. whoami')
    print('4. Nista od ponudjenog')
    odgovor=int(input('Izaberite tacan odgovor(1/2/3/4): '))
    if odgovor != 2:
        print('Odgovor nije tacan!')
    else:
        print('Odgovor je tacan')
        tacni = tacni + 1
    print('Pitanje 2.Koji od navedenih program se ne koristi za obradu teksta?')
    print('1. gimp')
    print('2. nano')
    print('3. notepad++')
    print('4. gedit')
    odgovor=int(input('Izaberite tacan odgovor(1/2/3/4): '))
    if odgovor != 1:
        print('Odgovor nije tacan!')
    else:
        print('Odgovor je tacan')
        tacni = tacni + 1
        print('Pitanje 3.Koja komanda omogucuje izvresenje sa administratorskim pravima?')
    print('1. pwd')
    print('2. cd /')
    print('3. sudo')
    print('4. touch')
    odgovor=int(input('Izaberite tacan odgovor(1/2/3/4): '))
    if odgovor != 3:
        print('Odgovor nije tacan!')
    else:
        print('Odgovor je tacan')
        tacni = tacni + 1
    print(ime," je ostvario/la ", tacni,"poena")
    m=int(input('Ako zelite novu igru pritisnite 1, za izlaz bilo sta drugo'))
    if m!=1 :
        nova=0
print("Kraj programa")
          
          
