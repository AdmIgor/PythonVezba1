a = int(input('Enter first number: '))
b = int(input('Enter second number: '))
print("Select operation: ")
print("1. Add")
print("2. Subtract")
print("3. Multiply")
print("4. Divide")
print("0. Exit")
c = int(input('Enter choice(1/2/3/4/0): '))
if c==1:
    print(a," + ",b," = ",a+b)
elif c==2:
    print(a," - ",b," = ",a-b)
elif c==3:
    print(a," * ",b," = ",a*b)
elif c==4:
    print(a," / ",b," = ",a/b)
elif c==0:
    print("End")
else:
    print("Input Error")
